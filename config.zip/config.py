# DATABASE_URI = 'postgresql://postgres:123456789qwe123!@localhost:5432/api_service_automation'
DATABASE_URI = 'postgresql://postgres:123456789qwe123!@185.246.67.169:39440/api_service_automation'